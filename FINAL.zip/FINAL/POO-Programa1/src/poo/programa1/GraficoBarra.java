/*
 * Instituto Tecnológico de Costa Rica
 */
package poo.programa1;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.ui.ApplicationFrame; 

/**
 * Esta clase fue creada para poder desplegar un gráfico de barra.
 * Esta clase utiliza el JFreeChart sugerido por la Profesora.
 * 
 * @author Orlando José Hidalgo Ramírez - 2016106829
 * @author Alejandro Tapia Barboza - 2016167784
 * @author Francisco Loaiza Vallejos - 2016123417
 */
public class GraficoBarra extends ApplicationFrame
{
    /**
     * Metodo Constructor, Este metodo crear el gráfico de las Meses vs Cantidad de Sismos
     * @param applicationTitle String - Título del frame (No es utilizado)
     * @param chartTitle String - Título del Gráfico
     */
    public GraficoBarra( String applicationTitle , String chartTitle)
    {
      super( applicationTitle );        
      JFreeChart barChart = ChartFactory.createBarChart(
         chartTitle,           
         "Mes",            
         "Número de Sismos",            
         createDatasetMeses(),          
         PlotOrientation.VERTICAL,           
         true, true, false);
         
      ChartPanel chartPanel = new ChartPanel( barChart );        
      //chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );        
      setContentPane( chartPanel ); 
   }
    /**
     * Metodo Constructor, Este metodo crear el gráfico de las Provincias vs Cantidad de Sismos
     * @param applicationTitle String - Título del frame (No es utilizado)
     * @param chartTitle String - Título del Gráfico
     * @param x String - Variable no utilizada para poder hacer polimorfismo.
     */
    public GraficoBarra( String applicationTitle , String chartTitle,String x)
    {
      super( applicationTitle );        
      JFreeChart barChart = ChartFactory.createBarChart(
         chartTitle,           
         "Provincia",            
         "Número de Sismos",            
         createDatasetProvincias(),          
         PlotOrientation.VERTICAL,           
         true, true, false);
         
      ChartPanel chartPanel = new ChartPanel( barChart );        
      //chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );        
      setContentPane( chartPanel ); 
   }
    /**
    * Crea y retorna un dataset para crear el grafico con los Meses y la 
    * cantidad de sismos ocurridos en cada uno de ellos.
    * @return dataset - Datos para el gráfico de los Meses.
    */
   private CategoryDataset createDatasetMeses( )
   {
      final String meses[] = {"Enero",
                              "Febrero",
                              "Marzo",
                              "Abril",
                              "Mayo",
                              "Junio",
                              "Julio",
                              "Agosto",
                              "Setiembre",
                              "Octubre",
                              "Noviembre",
                              "Diciembre"};
      final DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
      for (int mes = 0; mes<12;mes++)
      {
          dataset.addValue( Listas.getCantidadSismos(mes),meses[mes],meses[mes]);
      }             

      return dataset; 
   }
   /**
    * Crea y retorna un dataset para crear el grafico con las Provincias y la 
    * cantidad de sismos ocurridos en cada una de ellas.
    * @return dataset - Datos para el gráfico de las Provincias.
    */
   private CategoryDataset createDatasetProvincias( )
   {
      final String provincias[] = {"San_José",
                                   "Cartago",
                                   "Alajuela",
                                   "Heredia",
                                   "Limón",
                                   "Puntarenas",
                                   "Guanacaste",
                                   "Oceano_Pacífico",
                                   "Mar_Caribe",
                                   "Sin_Asignar"};
      
      final DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
      for (int x = 0; x<10;x++)
      {
          dataset.addValue( Listas.getCantidadSismos(Provincia.valueOf(provincias[x])),provincias[x],provincias[x]);
      }             

      return dataset; 
   }
}
