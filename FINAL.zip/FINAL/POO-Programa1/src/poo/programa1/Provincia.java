/*
 * Instituto Tecnológico de Costa Rica
 */
package poo.programa1;

/**
 * Esta clase es un enum de las posibles Provincias de los Sismos.<p>
 * Las posibles Provinicas son:
 * <ul>
 *  <li>San_José</li>
 *  <li>Cartago</li>
 *  <li>Alajuela</li>
 *  <li>Heredia</li>
 *  <li>Limón</li>
 *  <li>Puntarenas</li>
 *  <li>Guanacaste</li>
 *  <li>Oceano_Pacífico</li>
 *  <li>Mar_Caribe</li>
 *  <li>Sin_Asignar</li>
 * </ul>
 * @author Orlando José Hidalgo Ramírez - 2016106829
 * @author Alejandro Tapia Barboza - 2016167784
 * @author Francisco Loaiza Vallejos - 2016123417
 */
public enum Provincia 
{

    /**
     *
     */
    San_José,

    /**
     *
     */
    Cartago,

    /**
     *
     */
    Alajuela,

    /**
     *
     */
    Heredia,

    /**
     *
     */
    Limón, 

    /**
     *
     */
    Puntarenas,

    /**
     *
     */
    Guanacaste,

    /**
     *
     */
    Oceano_Pacífico,

    /**
     *
     */
    Mar_Caribe,

    /**
     *
     */
    Sin_Asignar
    
}
