/*
 * Instituto Tecnológico de Costa Rica
 */
package poo.programa1;

/**
 * Esta clase es un enum de los posibles Origenes de los Sismos.<p>
 * Los posibles Origenes son:
 * <ul>
 *  <li>Subducción</li>
 *  <li>Choque_Placas</li>
 *  <li>Tectonico_Falla_Local</li>
 *  <li>IntraPlaca</li>
 *  <li>Deformacion_Interna</li>
 * </ul>
 * @author Orlando José Hidalgo Ramírez - 2016106829
 * @author Alejandro Tapia Barboza - 2016167784
 * @author Francisco Loaiza Vallejos - 2016123417
 */
public enum Origen 
{

    /**
     *
     */
    Subducción,

    /**
     *
     */
    Choque_Placas,

    /**
     *
     */
    Tectonico_Falla_Local,

    /**
     *
     */
    IntraPlaca,

    /**
     *
     */
    Deformacion_Interna
}
