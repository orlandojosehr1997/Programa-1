/*
 * Instituto Tecnológico de Costa Rica
 */
package poo.programa1;

import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;

/**
 * Esta clase fue creada para poder desplegar un gráfico de pastel.
 * Esta clase utiliza el JFreeChart sugerido por la Profesora.
 * 
 * @author Orlando José Hidalgo Ramírez - 2016106829
 * @author Alejandro Tapia Barboza - 2016167784
 * @author Francisco Loaiza Vallejos - 2016123417
 */
public class GraficoPastel extends ApplicationFrame
{
    /**
     * Metodo Constructor, Este método crea un grafico de pastel.
     * @param title String - Titulo del Frame. No se utiliza.
     */
    public GraficoPastel( String title ) 
    {
        super( title ); 
        setContentPane(createDemoPanel());
    }
    /**
     * Crea un dataset de la informacion de cada uno de los tipos de 
     * origen y la cantidad de sismos que fueron causados por ese origen.
     * @return dataset - Datos para el gráfico de pastel.
     */
    private PieDataset createDataset( ) 
    {
        DefaultPieDataset dataset = new DefaultPieDataset();
        if(Listas.getCantidadSismos(Origen.Choque_Placas)!=0)
            dataset.setValue( Origen.Choque_Placas , Listas.getCantidadSismos(Origen.Choque_Placas));
        if(Listas.getCantidadSismos(Origen.Deformacion_Interna)!=0)
            dataset.setValue( Origen.Deformacion_Interna , Listas.getCantidadSismos(Origen.Deformacion_Interna)); 
        if(Listas.getCantidadSismos(Origen.IntraPlaca)!=0)
            dataset.setValue( Origen.IntraPlaca , Listas.getCantidadSismos(Origen.IntraPlaca)); 
        if(Listas.getCantidadSismos(Origen.Subducción)!=0)
            dataset.setValue( Origen.Subducción , Listas.getCantidadSismos(Origen.Subducción)); 
        if(Listas.getCantidadSismos(Origen.Tectonico_Falla_Local)!=0)
            dataset.setValue( Origen.Tectonico_Falla_Local , Listas.getCantidadSismos(Origen.Tectonico_Falla_Local)); 
        return dataset;         
    }
    /**
     * Recibe el dataset y crea el gráfico.
     * @param dataset dataset - Recibe los datos necesarios para crear el gráfico de pastel.
     * @return JFreeChart - Grafico de pastel creado.
     */
    private JFreeChart createChart(PieDataset dataset)
    {
        JFreeChart chart = ChartFactory.createPieChart(      
          "Cantidad de sismos por tipo de origen",
          dataset,       
          true,            
          true, 
          false);
        
        return chart;
   }
    /**
     * Recibe el gráfico y retorna JFreeChart.
     * @return JFreeChart - Grafico creado.
     */
    public JPanel createDemoPanel( )
    {
        JFreeChart chart = createChart(createDataset( ));  
        return new ChartPanel( chart ); 
    }
}
