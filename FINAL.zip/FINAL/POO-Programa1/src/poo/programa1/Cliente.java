/*
 * Instituto Tecnológico de Costa Rica
 */
package poo.programa1;

import java.util.ArrayList;

/**
 * La clase Cliente representa un cliente con los siguientes atributos:
 * <ul>
 *  <li>Nombre</li>
 *  <li>Correo</li>
 *  <li>Celular</li>
 *  <li>Lista de Provincias de las cuasles está interesado que lo notifiquen</li>
 *  <li>Interesado en notificar por celular [si/no]</li>
 *  <li>Interesado en notificar por correo [si/no]</li>
 * </ul>
 * @author Orlando José Hidalgo Ramírez - 2016106829
 * @author Alejandro Tapia Barboza - 2016167784
 * @author Francisco Loaiza Vallejos - 2016123417
 */
public class Cliente 
{
    private String nombre;
    private String correo;
    private String celular;
    private ArrayList<Provincia> provincia;
    private boolean notificarCorreo;
    private boolean notificarCelular;
    
    /**
     * Metodo Constructor, No utilizado.
     */
    public Cliente() {
    }
    /**
     * Metodo Constructor, No utilizado.
     * @param nombre String - Nombre del Cliente.
     * @param provincia ArrayList de Provincias - Provincias de las que desea ser notificado.
     */
    public Cliente(String nombre, ArrayList<Provincia> provincia) 
    {
        this.nombre = nombre;
        this.provincia = provincia;
        notificarCorreo = false;
        notificarCelular= false;
    }
    /**
     * Metodo Constructor, Este método incluye todos los atributos de la clase Cliente.
     * dentro de sus parametros.
     * @param nombre String - Nombre del Cliente.
     * @param correo String - Correo del Cliente.
     * @param celular String - Celular del Cliente.
     * @param provincia ArrayList de Provincias - Provincias de las que desea ser notificado.
     * @param notificarCorreo boolean - true si desea ser notificado por Correo.
     * @param notificarCelular boolean - true si desea ser notificado por Celular. NO FUNCIONA.
     */
    public Cliente(String nombre, String correo, String celular, ArrayList<Provincia> provincia, boolean notificarCorreo, boolean notificarCelular) 
    {
        this.nombre = nombre;
        this.correo = correo;
        this.celular = celular;
        this.provincia = provincia;
        this.notificarCorreo = notificarCorreo;
        this.notificarCelular = notificarCelular;
    }
    /**
     * Getter, Retorna el Nombre del Cliente.
     * @return String - Nombre del Cliente.
     */
    public String getNombre() 
    {
        return nombre;
    }
    /**
     * Setter, Cambia el Nombre del Cliente al indicado en el parámetro.
     * @param nombre String - Nuevo Nombre del Cliente.
     */
    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }
    /**
     * Getter, Retorna el Correo del Cliente.
     * @return String - Correo del Cliente.
     */
    public String getCorreo() 
    {
        return correo;
    }
    /**
     * Setter, Cambia el Correo del Cliente al indicado en el parámetro.
     * @param correo String - Nuevo Correo del Cliente.
     */
    public void setCorreo(String correo)
    {
        this.correo = correo;
    }
    /**
     * Getter, Retorna el Celular del Cliente.
     * @return String - Celular del Cliente.
     */
    public String getCelular()
    {
        return celular;
    }
    /**
     * Setter, Cambia el Celular del Cliente al indicado en el parámetro.
     * @param celular String - Nuevo Celular del Cliente.
     */
    public void setCelular(String celular) 
    {
        this.celular = celular;
    }
    /**
     * Este método le agrega la Provinica indicada en el parámetro a la lista de Provinicas
     * de las que quiere ser notificado el Cliente.  
     * @param provincia Provinica - Recibe un dato de tipo Provincia
     */
    public void agregarProvincia(Provincia provincia)
    {
        if ((this.provincia.contains(provincia))!=true)
            this.provincia.add(provincia);
    }
    /**
     * Getter, Retorna el valor de Notificar Correo, true, si quiere ser notificado 
     * por correo.
     * @return boolean - Retorna true si quiere ser notificado por correo.
     */
    public boolean isNotificarCorreo() 
    {
        return notificarCorreo;
    }
    /**
     * Setter, Cambia el valor de Notificar Correo al indicado en el parámetro si este
     * es posible, ya que no pueden estar ambos desactivados.
     * @param notificarCorreo boolean - Recibe si quiere ser notificado por correo o no.
     */
    public void setNotificarCorreo(boolean notificarCorreo) 
    {
        if (notificarCorreo)
            this.notificarCorreo = notificarCorreo;
        else if (isNotificarCelular())
            this.notificarCorreo = notificarCorreo;
        else
            this.notificarCorreo = true;
    }
    /**
     * Getter, Retorna el valor de Notificar Celular.
     * @return boolean - Retorna true si quiere ser notificado por celular.
     */
    public boolean isNotificarCelular()
    {
        return notificarCelular;
    }
    /**
     * Setter, Cambia el valor de Notificar Celular al indicado en el parámetro si este
     * es posible, ya que no pueden estar ambos desactivados.
     * @param notificarCelular boolean - Recibe si quiere ser notificado por celular o no.
     */
    public void setNotificarCelular(boolean notificarCelular) 
    {
        if (notificarCelular)
            this.notificarCelular = notificarCelular;
        else if (isNotificarCorreo())
            this.notificarCelular = notificarCelular;
        else
        {
            notificarCorreo = true;
            this.notificarCelular = false;
        }
    }
    /**
     * Este método verifica si la provinica indicada como parámetro se encuentra
     * dentro de las Provincias de interés del Cliente.
     * @param provincia Provincia - Recibe dato de tipo Provinica (enum).
     * @return boolean - Retorna true si está interezado en esta Provincia.
     */
    public boolean isInteresado(Provincia provincia)
    {
        return this.provincia.indexOf(provincia)!=-1;
    }
    
}
