/*
 * Instituto Tecnológico de Costa Rica
 */
package poo.programa1;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 *  Esta clase fue creada para poder accesar de manera organizada a la lista de sismos 
 * y lista de clientes en todo el programa. 
 * <p>
 * Contiene dos arraylists:
 * <ul>
 *  <li>listaSismos (ArrayList de sismos)</li>
 *  <li>listaClientes (ArrayList de clientes)</li>
 * </ul>
 * @author Orlando José Hidalgo Ramírez - 2016106829
 * @author Alejandro Tapia Barboza - 2016167784
 * @author Francisco Loaiza Vallejos - 2016123417
 */
public class Listas 
{
    private static ArrayList<Sismo> listaSismos = new ArrayList<>();;
    private static ArrayList<Cliente> listaClientes = new ArrayList<>();;
    /**
     * Este es el metodo constructor de esta clase, casi nunca es usado dado que 
     * todo en esta clase es static.
     */
    public Listas() 
    {
    }
    /**
     * Getter, Retorna el ArrayList de sismos.
     * @return ArrayList de Sismos - Retorna un ArrayList de objetos de la clase Sismo.
     */
    public static ArrayList<Sismo> getListaSismos() 
    {
        return listaSismos;
    }
    /**
     * Getter, Retorna el ArrayList de clientes.
     * @return ArrayList de Clietnes - Retorna un ArrayList de objetos de la clase Cliente.
     */
    public static ArrayList<Cliente> getListaClientes() 
    {
        return listaClientes;
    }
    /**
     * Agrega un simsmo al ArrayList listaSismo.
     * @param sismo Sismo - Recibe un objeto de la clase Sismo.
     */
    public static void agregarSismo(Sismo sismo)
    {
        listaSismos.add(sismo);
    }
    /**
     * Agrega un cliente al ArrayList listaCliente.
     * @param cliente Cliente - Recibe un objeto de la clase Cliente.
     */
    public static void agregarCliente(Cliente cliente)
    {
        listaClientes.add(cliente);
    }
    /**
     * Getter, Este método busca entre todos los elementos del ArrayList listaSismo
     * y guarda en un array todas las fechas de los elementos en el ArrayList.
     * @return String[] - Fechas de los elementos del ArrayList.
     */
    public static String[] getFechas()
    {
        String fechas[] = new String[listaSismos.size()];
        int contador = 0;
        for (Sismo sismo : listaSismos) 
        {
            fechas[contador++] = sismo.getFecha2();
        }
        return fechas;
    }
    /**
     * Getter, Sobrecarga del metodo getCantidadSismos, Este metodo recibe una 
     * instancia de la clase Provincia y retorna la cantidad de sismos dentro
     * del ArrayList listaSismo que ocurrieron en esta Provincia
     * @param provincia Provinica - Elemento de tipo Provincia.
     * @return int - Cantidad de sismos en la Provincia indicada en el parametro.
     */
    public static int getCantidadSismos(Provincia provincia)
    {
        int contador = 0;
        for (Sismo sismo : listaSismos) 
        {
            if (sismo.getProvincia().equals(provincia))
                contador++;
        }
        return contador;
    }
    /**
     * Getter, Sobrecarga del metodo getCantidadSismos. Este metodo recibe una 
     * instancia de la clase Origen y retorna la cantidad de sismos dentro
     * del ArrayList listaSismo que ocurrieron por este origen.
     * @param origen Origen - Elemento de tipo Origen. 
     * @return int - Cantidad de sismos con Origen dado en el parámetro.
     */
    public static int getCantidadSismos(Origen origen)
    {
        int contador = 0;
        for (Sismo sismo : listaSismos) 
        {
            if (sismo.getOrigen().equals(origen))
                contador++;
        }
        return contador;
    }
    /**
     * Getter, Sobrecarga del metodo getCantidadSismos. Este metodo recibe un String 
     * que representa el Valor de Magnitud de un sismo y retorna la cantidad de 
     * sismos dentro del ArrayList listaSismo que fueron clasificados con este mismo
     * Valor de Magnitud.
     * @param valorMagnitud String - Valor de Magnitud.
     * @return int - Cantidad de sismos con el Valor de Magnitud dado en el parámetro.
     */
    public static int getCantidadSismos(String valorMagnitud)
    {
        int contador = 0;
        for (Sismo sismo : listaSismos) 
        {
            if (sismo.getValorMagnitud().compareTo(valorMagnitud)==0)
                contador++;
        }
        return contador;
    }
    /**
     * Getter, Sobrecarga del metodo getCantidadSismos. Este metodo recibe un valor 
     * numérico del 0-11, representado el mes (Siendo Enero el 0) y retorna la 
     * cantidad de sismos dentro del ArrayList listaSismo que ocurrieron en el Mes
     * dado como parámetro.
     * @param mes int - valor numérico del 0-11, representado el mes (Siendo Enero el 0)
     * @return int - Cantidad de sismos que ocurrieron en el mes dado como parámetro.
     */
    public static int getCantidadSismos(int mes)
    {
        int contador = 0;
        for (Sismo sismo : listaSismos) 
        {
            Date fecha = sismo.getFechaDate();
            Calendar calendario = Calendar.getInstance();
            calendario.setTime(fecha);
            int Mes = calendario.get(Calendar.MONTH);
            if (Mes == mes)
                contador++;
        }
        return contador;
    }
}
